export class Train {
    constructor(
        public trainName:string,
        public from_to:string,
        public day:string,
        public time:string,
        public capacity:number,
        public charge:number,
    ){}

}
