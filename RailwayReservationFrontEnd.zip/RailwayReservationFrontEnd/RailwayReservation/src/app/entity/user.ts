export class User {
    constructor(
        public userName:string,
        public gender:string,
        public date:string,
        public phNo:number,
        public adharNo:number,
    )
{}    

}
